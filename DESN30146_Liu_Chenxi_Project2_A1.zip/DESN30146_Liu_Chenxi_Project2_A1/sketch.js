/*
The majority of the code structure was created by Doug Whitton, studied and modified by Chenxi Liu 
The Arduino file that's running is "week6-threeSensorExample"
*/

let osc;
let playing = false;
let serial;
let latestData = "waiting for data";  // you'll use this to write incoming data to the canvas
let splitter;
let diameter0 = 0, diameter1 = 0, diameter2 = 0;

let osc1, osc2, osc3, fft;

function setup() {
  createCanvas(windowWidth, windowHeight);
  setupSerialPort();
}

function setupSerialPort(){


  
  serial = new p5.SerialPort();

  
  serial.list();
  console.log("serial.list()   ", serial.list());

  
  serial.open('COM3');
 

  
  serial.on('connected', serverConnected);

  
  serial.on('list', gotList);
  
  
  serial.on('data', gotData);
  

  
  serial.on('error', gotError);
  
  serial.on('open', gotOpen);
  
}


osc1 = new p5.TriOsc(); 
osc1.amp(.5);
osc2 = new p5.TriOsc(); 
osc2.amp(.5);
osc3 = new p5.TriOsc(); 
osc3.amp(.5);

fft = new p5.FFT();
osc1.start();
osc2.start();
osc3.start();


function serverConnected() {
  console.log("Connected to Server");
}


function gotList(thelist) {
  console.log("List of Serial Ports:");
  
  for (var i = 0; i < thelist.length; i++) {
    
    console.log(i + " " + thelist[i]);
  }
}


function gotOpen() {
  console.log("Serial Port is Open");
}


function gotError(theerror) {
  console.log(theerror);
}




function gotData() {
  var currentString = serial.readLine();  
  trim(currentString);                   
  if (!currentString) return;             
  console.log("currentString  ", currentString);             
  latestData = currentString;            
  console.log("latestData" + latestData);   
  splitter = split(latestData, ',');       
 
  diameter0 = splitter[0];            
  diameter1 = splitter[1];
  diameter2 = splitter[2];
}


function gotRawData(thedata) {
  println("gotRawData" + thedata);
}




function draw() {
  background(255,165,0);
  text(latestData, 10,10);
  drawEllipse();
  drawSineWave();
  playSound();

}

function playSound(){
  var freq = map(diameter0, 0, width, 40, 880);
  osc1.freq(freq);
  //console.log(freq);
  var freq2 = map(diameter1, 0, width, 40, 880);
  osc2.freq(freq2);
  //console.log(freq2);
  var freq3 = map(diameter2*10, 0, width, 40, 880);
  osc3.freq(freq3);
  //console.log(freq3);
}

function drawEllipse(){
  ellipseMode(RADIUS);
  fill(255,200,0);
  noStroke();
  ellipse(1250, 650, diameter0*400, diameter0*400);

  ellipseMode(CENTER);
  fill(69,69,69);
  ellipse(1250, 650, diameter1, diameter1); 

  //ellipseMode(RADIUS);
  //fill(0,0,255);
  //ellipse(300, 100, diameter2, diameter2);
}

// Wave loop was found and modified from the p5 example at: https://p5js.org/examples/math-sine-wave.html
let theta = 0.0; 
function drawSineWave(){
    var xspacing = 1; 
    var amplitude = 75.0; 
    var period = 500.0; 
    var w = windowWidth + 16;
    var dx = (TWO_PI / period) * xspacing;
    var yvalues = new Array(floor(w / xspacing));
    var freq = map(diameter2, 0, 1024, 1, 10);

    theta += 0.02;
    let x = theta;
    for (let i = 0; i < yvalues.length; i++) {
      yvalues[i] = sin(freq*x) * amplitude;
      x += dx;
    }
    noStroke();
    fill(248,222,126);
    
    for (let i = 0; i < yvalues.length; i++) {
      ellipse(i * xspacing, height / 2 + yvalues[i], 16, 16);
    }
}

function mouseClicked(){
  if (getAudioContext().state !== 'running') {
    getAudioContext().resume();
    console.log("getAudioContext().state" + getAudioContext().state);
  }
};